package com.example.speechrecognition

import android.content.Intent
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer

class AboutRobo : AppCompatActivity() {

    private lateinit var rippleView: RippleView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_robo)

        rippleView = findViewById(R.id.circle_ripple_2)

        val mp1: MediaPlayer = MediaPlayer.create(this, R.raw.knowme)
        if (mp1.isPlaying) {
            mp1.stop()
            mp1.release()
        } else {
            mp1.start()

            object : CountDownTimer(14000, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    rippleView.newRipple()
                }

                override fun onFinish() {
                    onBackPressed()
                }
            }.start()
        }
    }
        override fun onBackPressed() {
            super.onBackPressed()
            val intent = Intent(this,MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
}
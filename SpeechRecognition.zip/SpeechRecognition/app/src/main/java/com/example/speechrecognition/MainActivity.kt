package com.example.speechrecognition

import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageManager
import android.media.MediaParser
import android.media.MediaPlayer
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.example.speechrecognition.SpeechRecognizerViewModel
import java.util.jar.Manifest
import kotlin.system.exitProcess


class MainActivity : AppCompatActivity() {

    private val REQUEST_RECORD_AUDIO_PERMISSION = 200
    private val permission = arrayOf(android.Manifest.permission.RECORD_AUDIO)
    private lateinit var speechRecognizerModel: SpeechRecognizerViewModel

    private lateinit var titleText: TextView
    private lateinit var roboButton: Button
    private lateinit var helpButton: Button
    private lateinit var webButton: Button
    private lateinit var knowmeButton: Button
    private lateinit var moodleButton: Button
    private lateinit var songButton: Button
    private lateinit var rippleView: RippleView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        titleText = findViewById(R.id.spoken_text)
        roboButton = findViewById<Button>(R.id.robo_button).apply {
            setOnClickListener(roboClickListener)
        }
        helpButton = findViewById<Button>(R.id.button_help).apply {
            setOnClickListener(helpClickListener)
        }
        webButton = findViewById<Button>(R.id.button_web).apply {
            setOnClickListener(webClickListener)
        }
        knowmeButton = findViewById<Button>(R.id.button_knowme).apply {
            setOnClickListener(knowmeClickListener)
        }
        moodleButton = findViewById<Button>(R.id.button_moodle).apply {
            setOnClickListener(moodleClickListener)
        }
        songButton = findViewById<Button>(R.id.button_song).apply {
            setOnClickListener(songClickListener)
        }
        rippleView = findViewById(R.id.circle_ripple)

        setupSpeechViewModel()

    }
    private val helpClickListener = View.OnClickListener {
        val intent =  Intent(this, HelpActivity::class.java)
        startActivity(intent)
    }

    private val webClickListener = View.OnClickListener {
        goWeb()
    }

    private val knowmeClickListener = View.OnClickListener {
        goIntroduce()
    }

    private val moodleClickListener = View.OnClickListener {
        goMoodle()
    }

    private val songClickListener = View.OnClickListener {
        playMusic()
    }

    private val roboClickListener = View.OnClickListener {
      //  if(::speechRecognizerModel.isInitialized) {
            Log.d("tag","udah di klik")
            if (!speechRecognizerModel.permissionToRecordAudio) {
                Log.d("tag","minta akses")
                ActivityCompat.requestPermissions(this, permission, REQUEST_RECORD_AUDIO_PERMISSION)
                return@OnClickListener
            }
            if (speechRecognizerModel.isListening) {
                Log.d("tag","matiin")
                speechRecognizerModel.stopListening()
            } else {
                Log.d("tag","mulai")
                speechRecognizerModel.startListening()
            }
       // }else{
      //      Log.d("tag","masuk ga")
      //  }
    }
    private fun setupSpeechViewModel(){
      //  if(::speechRecognizerModel.isInitialized) {
            speechRecognizerModel =
                ViewModelProviders.of(this).get(SpeechRecognizerViewModel::class.java)
            speechRecognizerModel.getViewState()
                .observe(this, Observer<SpeechRecognizerViewModel.ViewState>
                { viewState ->
                    render(viewState)
                })
       // }
    }

    val txt_1 = "1"
    val txt_11 = "help"
    val txt_2 = "2"
    val txt_22 = "what is your name"
    val txt_222 = "who are you"
    val txt_2222 = "name please"
    val txt_3 = "3"
    val txt_33 = "open website"
    val txt_4 = "4"
    val txt_44 = "open Google"
    val txt_5 = "5"
    val txt_55 = "play music"

    private fun render(uiOutput: SpeechRecognizerViewModel.ViewState?){
        if(uiOutput ==  null) return
        titleText.text = uiOutput.spokenText
        uiOutput.spokenText = "Say 1 for help"

        when(titleText.text){
            txt_1, txt_11 -> goHelp()
            txt_2, txt_22, txt_222, txt_2222 -> goIntroduce()
            txt_3, txt_33 -> goMoodle()
            txt_4, txt_44 -> goWeb()
            txt_5, txt_55 -> playMusic()
        }

        roboButton.background = if(uiOutput.isListening){
            ContextCompat.getDrawable(this,R.drawable.image2vector)
        }else{
            ContextCompat.getDrawable(this, R.drawable.image2vector)
        }
        if(uiOutput.rmsDbChanged){
            rippleView.newRipple()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode == REQUEST_RECORD_AUDIO_PERMISSION){
            speechRecognizerModel.permissionToRecordAudio = grantResults[0] == PackageManager.PERMISSION_GRANTED
        }
        if(speechRecognizerModel.permissionToRecordAudio){
            roboButton.performClick()
        }
    }

    fun goHelp(){
        val intent =  Intent(this, HelpActivity::class.java)
        startActivity(intent)
    }
    fun goIntroduce(){
        val intent = Intent(this,AboutRobo::class.java)
        startActivity(intent)
    }
    fun playMusic(){
        val mp1: MediaPlayer = MediaPlayer.create(this,R.raw.play_music)
        if(mp1.isPlaying){
            mp1.stop()
            mp1.release()
        }else{
            mp1.start()

            object : CountDownTimer(13000,1000){
                override fun onTick(millisUntilFinished: Long){
                    rippleView.newRipple()
                }

                override fun onFinish() {
                }
            }.start()
        }
    }
    fun goMoodle(){
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://learn.uph.edu")
            Toast.makeText(this@MainActivity, "Loading", Toast.LENGTH_LONG).show()
        }
        startActivity(intent)
    }
    fun goWeb(){
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://google.com")
            Toast.makeText(this@MainActivity, "Loading", Toast.LENGTH_LONG).show()
        }
        startActivity(intent)
    }

    private var doubleBackToExitPressedOnce = false
    override fun onBackPressed() {
        if(doubleBackToExitPressedOnce){
            super.onBackPressed()
            val intent = Intent(Intent.ACTION_MAIN)
            intent.addCategory(Intent.CATEGORY_HOME)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
            exitProcess(0)
        }
        this.doubleBackToExitPressedOnce = true
        Toast.makeText(this, "pressed again to Exit",Toast.LENGTH_SHORT).show()

        Handler().postDelayed(Runnable { doubleBackToExitPressedOnce = false }, 3000)
    }

}